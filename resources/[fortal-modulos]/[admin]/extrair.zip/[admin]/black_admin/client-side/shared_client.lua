Utils = {}

Utils.functions = {
    getUserData = function(data)
        return exports["hud"]:getUserData(data)
    end
}