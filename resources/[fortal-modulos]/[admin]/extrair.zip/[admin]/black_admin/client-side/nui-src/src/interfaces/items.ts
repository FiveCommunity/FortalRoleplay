export interface Item {
  name: string;
  spawn: string;
  image: string;
}
