export interface Permission {
  name: string;
  id: number;
}
