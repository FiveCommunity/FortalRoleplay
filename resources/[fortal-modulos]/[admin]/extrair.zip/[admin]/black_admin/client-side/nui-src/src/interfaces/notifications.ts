export interface Notification {
  message: string;
  date: string;
}
