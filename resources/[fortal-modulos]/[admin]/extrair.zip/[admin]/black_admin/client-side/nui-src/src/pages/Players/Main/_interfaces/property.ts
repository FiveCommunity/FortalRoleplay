export interface Property {
  name: string;
  street: string;
}
