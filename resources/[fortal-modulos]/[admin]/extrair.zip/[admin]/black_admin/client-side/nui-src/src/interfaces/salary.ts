export interface SalaryGroup {
  name: string;
  group: string;
  members: number[];
  salary: number;
}
